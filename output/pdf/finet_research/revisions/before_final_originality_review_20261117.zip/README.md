# LaTeX research paper

Open `paper.tex` with the supplied `figures` folder, or import `finet_latex_source.zip` into Overleaf. Compile with pdfLaTeX twice. References are included in the source; no BibTeX file is required. The verified local preview is `paper.pdf`.

The layout uses `IEEEtran` in conference mode on US Letter paper, matching the supplied PDF. Default fonts, margins, columns and spacing are retained. The four supplied authors appear in reading order. Email addresses were not supplied and are omitted. The template does not specify a submission page limit.

The expanded paper is seven pages in the supplied IEEE conference style, with ten tables, twenty numbered equation groups and four figures. It states the research objectives and separates A/B controls from domain differences. Equations cover RGB/DCT preprocessing, the exact baseline and boundary losses, sampling, scheduling, native inference and metrics. Tables specify tensor shapes, optimization settings, splits, saved budgets, output exports, validation results and native TP/FP/FN counts.

Both application domains include real images, ground truth, probability maps, masks and pixel error maps. Camouflage results include two completed models and their validation comparison. Industrial examples use the completed independent baseline. A matched final industrial boundary result is unavailable in the verified artifact set. Individual examples are not dataset averages, and no aggregate quality or production accuracy claim is made.

`evidence.json` records source hashes and the numerical calculation behind the reported MAE difference. `source_map.md` maps the paper's measurements and references to their sources. `build_figures.py` regenerates the figures in the project environment without training or inference.

The expanded prose retains the plain academic style of the earlier Humanizer edit. All seven main sections, the abstract and captions were reviewed. The user-authorized expansion adds formulas and tables while retaining the original measurements. `humanizer_review.json` describes the current editorial pass. `technical_verification.json` records numerical checks of the equations against the implementation and verification of the three final checkpoint hashes. These checks are engineering evidence, not new training or segmentation experiments. Earlier versions are preserved under `revisions/`.
