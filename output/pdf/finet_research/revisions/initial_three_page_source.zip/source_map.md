# Research evidence

Paths below are relative to the repository root. None of the original FINet publication's benchmark values are presented as results of this project.

| Paper content | Evidence |
|---|---|
| Inference architecture, initialization and DCT inputs | `Model/FINet.py`, `Model/EfficientNet.py`, `utils/dataloader_freq.py`, `utils/dct.py`, `src/preprocessing.py` |
| Original structure loss and scalar BCE behavior | `train.py`, function `structure_loss` |
| Morphological boundary, BCE clamping, Dice smoothing and four head objective | `src/boundary_loss.py` |
| Matched training configuration, seed and scheduler | `configs/baseline.json`, `configs/boundary.json`, `src/training.py`, `utils/LRScheduler.py` |
| Both camouflage runs completed 200 epochs and 181800 updates | `outputs/kaggle_migration/kaggle_version005_completion_verification.json` |
| Camouflage final and minimum validation MAE | `outputs/final_camouflage_training/summary.json`; continuous `epochs.jsonl` histories under `outputs/kaggle_migration/version005/FINet/experiments/` |
| Fixed camouflage development split | Saved `split_manifest.json` in those experiments; fingerprint `2100aa40c52f01442d59b28973fee653eec655e370c8b1c1ff3c8d40cf61d724` |
| Supervised MVTec splits and all 15 categories | `data/MVTecAD_supervised_v1/split_manifest.json`; canonical GPU manifest in `outputs/industrial_setup/version004/FINetIndustrial/split_manifest.json` |
| Industrial final baseline and 186400 updates | `outputs/industrial_setup/industrial_version004_checkpoint_verification.json` |
| Industrial masks and sample measurements | `outputs/industrial_three_samples_20261116/report.json`, `results.csv`, individual float probability maps and original masks |
| Boundary F1 tolerance and empty mask convention | `src/evaluation_metrics.py`, `src/industrial_training.py` |

The evidence builder rechecks the 200 epoch histories, 404 validation samples, exact saved industrial binary masks, and Dice and IoU counts. Source hashes and final MAE calculations are in `evidence.json`. No new experiment was run to select a favorable result.

## Primary reference sources

1. FINet publication metadata and authors' implementation: https://github.com/CRRCOO/FINet and https://doi.org/10.1109/LSP.2024.3356416
2. EfficientNet proceedings record: https://proceedings.mlr.press/v97/tan19a.html
3. COD10K publication: https://openaccess.thecvf.com/content_CVPR_2020/html/Fan_Camouflaged_Object_Detection_CVPR_2020_paper.html
4. CAMO publication and journal metadata: https://arxiv.org/abs/2105.09451 and https://doi.org/10.1016/j.cviu.2019.04.006
5. MVTec dataset and author publication record: https://www.mvtec.com/research-teaching/datasets/mvtec-ad and https://www.mvtec.com/research-teaching/publications

## Availability checked during preparation

On November 16, 2026, the camouflage evaluation Version 6 link returned "We can't find that page" in the current Chrome Kaggle account. This does not prove that evaluation failed or produced no outputs. Its aggregate results remain unavailable for independent verification and are not reported.

The industrial Version 5 log was accessible and showed a running Tesla T4 job with actual epoch 26 updates through at least step 24050 and finite gradients. These live updates are not a completed saved checkpoint or a final industrial result. The latest independently downloaded boundary recovery remains epoch 6. The job was only read; its source, settings and execution were unchanged.
