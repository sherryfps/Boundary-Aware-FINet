# LaTeX research paper

Open `paper.tex` with the supplied `figures` folder, or import `finet_latex_source.zip` into Overleaf. Compile with pdfLaTeX twice. References are included in the source; no BibTeX file is required. The verified local preview is `paper.pdf`.

The layout uses `IEEEtran` in conference mode on US Letter paper, matching the supplied PDF. Default fonts, margins, columns and spacing are retained. The four supplied authors appear in reading order. Email addresses were not supplied and are omitted. The template does not specify a submission page limit.

Both application domains are explicit in the title and experiment sections. Camouflage results include the 200 epoch validation comparison and a native resolution CAMO example with input, ground truth, baseline prediction, boundary prediction and independently rechecked metrics. Industrial results retain the three recorded baseline examples. These do not establish aggregate test improvement, boundary improvement or production accuracy. The industrial boundary experiment is incomplete. The text is prepared from the project's records and should be reviewed by all authors before submission. No claim about passing an AI detector is made.

`evidence.json` records source hashes and the numerical calculation behind the reported MAE difference. `source_map.md` maps the paper's measurements and references to their sources. `build_figures.py` regenerates the figures in the project environment without training or inference.

The full paper received a Humanizer prose edit on November 17, 2026. All six main sections, the abstract and captions were reviewed. Numerical values, equations, table data, author details, references and figure files are unchanged. `humanizer_review.json` records the preservation checks. The revised PDF retains the three-page IEEE layout.
