"""Build paper figures from recorded measurements and actual inference artifacts."""
from pathlib import Path
import json
import hashlib
import sys
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
from src.evaluation_metrics import read_ground_truth, metrics_for_pair
FIGURES = HERE / 'figures'
FIGURES.mkdir(exist_ok=True)
plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['Times New Roman'],
    'font.size': 8, 'axes.labelsize': 8, 'xtick.labelsize': 8,
    'ytick.labelsize': 8, 'legend.fontsize': 8, 'pdf.fonttype': 42,
})

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

source_root = ROOT / 'outputs/kaggle_migration/version005/FINet/experiments'
histories = {}
fig, ax = plt.subplots(figsize=(3.5, 1.65), constrained_layout=True)
for variant, color, style in [('baseline', '#24577f', '-'), ('boundary', '#a1421a', '--')]:
    source = source_root / f'{variant}_seed123456_b4_v1/epochs.jsonl'
    rows = [json.loads(line) for line in source.read_text().splitlines() if line.strip()]
    rows = [row for row in rows if 'epoch' in row]
    assert [r['epoch'] for r in rows] == list(range(1, 201))
    assert all(r['validation']['samples'] == 404 for r in rows)
    values = [r['validation']['mae'] for r in rows]
    histories[variant] = {'source': str(source.relative_to(ROOT)), 'sha256': sha(source),
                          'final_validation_mae': values[-1], 'epochs': len(rows)}
    ax.plot(range(1, 201), values, label=variant.capitalize(), color=color, linestyle=style, linewidth=1)
ax.set(xlabel='Epoch', ylabel='Validation MAE', xlim=(1, 200))
ax.spines[['top', 'right']].set_visible(False)
ax.grid(axis='y', color='#dddddd', linewidth=.4)
ax.legend(frameon=False, loc='upper right')
fig.savefig(FIGURES / 'validation_mae.pdf')
fig.savefig(FIGURES / 'validation_mae.png', dpi=300)
plt.close(fig)

camo_root = ROOT / 'outputs/final_camouflage_app'
camo_verification = read_json(camo_root / 'verification.json')
sample_id = camo_verification['sample_id']
assert camo_verification['status'] == 'passed' and sample_id == 'camourflage_00012'
image_path = ROOT / f'data/TestDataset/CAMO/Imgs/{sample_id}.jpg'
target_path = ROOT / f'data/TestDataset/CAMO/GT/{sample_id}.png'
original = Image.open(image_path).convert('RGB')
target = read_ground_truth(target_path, (original.height, original.width))
development = read_json(source_root / 'baseline_seed123456_b4_v1/split_manifest.json')
assert sample_id not in {r['id'] for r in development['records']}
camo = {'sample_id': sample_id, 'native_size_wh': list(original.size),
        'image_sha256': sha(image_path), 'ground_truth_sha256': sha(target_path),
        'absent_from_development_manifest': True,
        'scope': 'One previously demonstrated CAMO test example; not an aggregate or random sample.'}
panels = [('Input', original), ('Ground truth', target)]
for variant, folder_name, expected_hash in [
    ('baseline', '473a9caeeccc41b481abc9b6bae86eba', '660a43bc1f5d57cbfd58d5cec7dd452f592932f34e1b8931567a30784af62810'),
    ('boundary', '22f0806f5f04488baf5e3b8f592b88ac', 'c7859e2b2445dbc195dfc1f94908c862f678871e286eb6a1dd99ef45f3caee48'),
]:
    folder = camo_root / folder_name
    saved = read_json(folder / 'prediction.json')
    assert saved['checkpoint_sha256'] == expected_hash
    assert sha(ROOT / f'checkpoints/{variant}/last.pth') == expected_hash
    assert saved['training_progress']['completed_epochs'] == 200 and saved['threshold'] == .5
    probability = np.load(folder / 'probability.npy')
    binary = probability >= .5
    assert np.array_equal(binary, np.asarray(Image.open(folder / 'binary.png')) > 0)
    assert np.array_equal(np.asarray(original), np.asarray(Image.open(folder / 'original.png').convert('RGB')))
    metrics = metrics_for_pair(probability, target, threshold=.5, tolerance_pixels=2)
    assert all(abs(metrics[k] - saved['ground_truth_metrics'][k]) < 1e-12
               for k in ['mae', 'boundary_f1', 's_measure'])
    intersection = np.logical_and(binary, target).sum()
    total = binary.sum() + target.sum()
    union = np.logical_or(binary, target).sum()
    metrics.update(dice=float(2*intersection/total), iou=float(intersection/union))
    camo[variant] = {'checkpoint_sha256': expected_hash, 'metrics': metrics,
                     'probability_sha256': sha(folder / 'probability.npy')}
    panels.append((variant.capitalize(), binary))
fig, axes = plt.subplots(2, 2, figsize=(3.5, 2.5), constrained_layout=True)
for ax, (title, data) in zip(axes.flat, panels):
    ax.imshow(data, cmap='gray', interpolation='nearest')
    ax.set_title(title, pad=3)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_linewidth(.4)
fig.savefig(FIGURES / 'camouflage_example.pdf', dpi=240)
fig.savefig(FIGURES / 'camouflage_example.png', dpi=300)
plt.close(fig)

samples_root = ROOT / 'outputs/industrial_three_samples_20261116'
report = read_json(samples_root / 'report.json')
assert report['status'] == 'passed' and report['completed_epochs'] == 200
assert report['threshold'] == .5 and len(report['samples']) == 3
fig, axes = plt.subplots(3, 3, figsize=(3.5, 3.05), constrained_layout=True)
for col, title in enumerate(['Input', 'Ground truth', 'Prediction']):
    axes[0, col].set_title(title, pad=4)
for row, record in enumerate(report['samples']):
    folder = samples_root / record['id']
    probability = np.load(folder / 'probability.npy')
    binary = np.array(Image.open(folder / 'binary.png').convert('L')) > 0
    target = np.array(Image.open(folder / 'ground_truth.png').convert('L')) > 0
    assert np.array_equal(binary, probability >= .5)
    union = np.logical_or(binary, target).sum()
    total = binary.sum() + target.sum()
    intersection = np.logical_and(binary, target).sum()
    assert abs((2 * intersection / total if total else 1) - record['dice']) < 1e-12
    assert abs((intersection / union if union else 1) - record['iou']) < 1e-12
    for col, filename in enumerate(['original.png', 'ground_truth.png', 'binary.png']):
        image = Image.open(folder / filename)
        assert image.size == (probability.shape[1], probability.shape[0])
        axes[row, col].imshow(image, cmap='gray', vmin=0, vmax=255, interpolation='nearest')
        axes[row, col].set_xticks([])
        axes[row, col].set_yticks([])
        for spine in axes[row, col].spines.values():
            spine.set_linewidth(.4)
fig.savefig(FIGURES / 'industrial_examples.pdf', dpi=220)
fig.savefig(FIGURES / 'industrial_examples.png', dpi=300)
plt.close(fig)

baseline, boundary = [histories[v]['final_validation_mae'] for v in ['baseline', 'boundary']]
evidence = {
    'format_source': r'C:\Users\hrish\Downloads\grfzhhncsfqn.pdf',
    'format': 'IEEEtran conference, US Letter, 10 pt, two columns, default geometry',
    'camouflage_histories': histories,
    'camouflage_example': camo,
    'final_mae_absolute_decrease': baseline-boundary,
    'final_mae_relative_decrease_percent': 100*(baseline-boundary)/baseline,
    'industrial_source': str((samples_root / 'report.json').relative_to(ROOT)),
    'industrial_report_sha256': sha(samples_root / 'report.json'),
    'industrial_checkpoint_sha256': report['checkpoint_sha256'],
    'scope': 'Camouflage validation, one same-image camouflage comparison and three industrial baseline examples; no aggregate test improvement claimed.',
}
(HERE / 'evidence.json').write_text(json.dumps(evidence, indent=2), encoding='utf-8')
print(json.dumps(evidence, indent=2))
